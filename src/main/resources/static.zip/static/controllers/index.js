'use strict';

/**
 * @ngdoc function
 * @name demineurApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the demineurApp
 */
angular.module('SpiApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
