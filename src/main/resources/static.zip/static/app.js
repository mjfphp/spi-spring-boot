
var app = angular.module('SpiApp', [
		'ngRoute'
	])
	.config(function ($routeProvider) {
		$routeProvider
			.when('/formations', {
				templateUrl: 'views/formations.html',
				controller: 'formationController'
			})
			.otherwise({
				redirectTo: '/'
			});
	});


