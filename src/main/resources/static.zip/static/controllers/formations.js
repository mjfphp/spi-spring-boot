
app.controller('formationController', function($scope, $http) {
	
	$scope.IsVisible = false ;
	// $http is a service used to make request using ajax
	// $scope is a service that holds the variables that angular should watch
	
	
	// request all data from database to show it in the table
    $http.get("/formations")
    .then(function(response) {
        $scope.formations = response.data;
    });
    
    $scope.detail=function(nom){
	   console.log("dddadazdaz");
	   $http.get("/formations/nom/"+nom)
	   .then( function(response){
		   $scope.IsVisible = $scope.IsVisible =true ;
		   $scope.detailFormation=response.data;
	   });
   }
    $scope.savedata = function(){
        
    	console.log($scope.codeFormationput+" "+$scope.formationput);
    	
    	var obj = {};
    	obj.codeFormation = $scope.codeFormationput;
    	obj.nomFormation = $scope.formationput;
    	obj.diplome = "M";
    	obj.n0Annee= "1";
    	obj.doubleDiplome="O";
    obj.finAccreditation="2017-09-30";
    	obj.debutAccreditation="2017-09-30";
    	
    	console.log(obj);
    	$http.post("/formations",obj)
    	.then(function(){
    		console.log("done");
    		
    	    $http.get("/formations")
    	    .then(function(response) {
    	        $scope.formations = response.data;
    	    });
    		
    	});
   
    	
    };
    
});